Pulse-Oximetry-with-AFE4490
===========================
Date: 23 June 2013


Hey, There!
This is a sketch of pulse oximetry using NJL5501r-reflectance phototransistor and Texas Instruments'
AFE4490- Analogue Front End.

Pulse oximetry is a method to measure oxygen saturation in a blood that carried by haemoglobin. The pulse oximetry method has been widely used in most of medical procedure. Nowadays, the pulse oximetry method has been simplified using a small device with red and infrared LED and phototransistor which is available in portable size and affordable price, accurate and high efficiency. 

As this sketch is made by beginner programmer, 
feel free to critize an error, since the purpose of this repository is to learn.


Stella Laksono
